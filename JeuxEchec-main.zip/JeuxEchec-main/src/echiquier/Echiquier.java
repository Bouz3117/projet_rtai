package echiquier;

import java.util.ArrayList;
import java.util.List;

import joueur.Joueur;
import piece.Couleur;
import piece.Piece;
import piece.Vecteur;
import piece.pieceSpeciale.Cavalier;
import piece.pieceSpeciale.Damme;
import piece.pieceSpeciale.Fou;
import piece.pieceSpeciale.Pion;
import piece.pieceSpeciale.Roi;
import piece.pieceSpeciale.Tour;

public class Echiquier {

	private List<List<Case>> tableuCase;
	private Joueur joueurBlanc;
	private Joueur joueurNoir;

	public Echiquier() {
		this.tableuCase = new ArrayList<>();
	}

	public void initialiserEchiquier() {

		initialiserCase();

		//initialiserPion(Couleur.BLANC);
		initialiserPion(Couleur.NOIR);

		initialiserTour(Couleur.BLANC);
		initialiserTour(Couleur.NOIR);

		initialiserCavalier(Couleur.BLANC);
		initialiserCavalier(Couleur.NOIR);

		initialiserFou(Couleur.BLANC);
		initialiserFou(Couleur.NOIR);

		initialiserDamme(Couleur.BLANC);
		initialiserDamme(Couleur.NOIR);

		initialiserRoi(Couleur.BLANC);
		initialiserRoi(Couleur.NOIR);
	}

	private void initialiserCase() {
		for (int y = 0; y < 8; y++) {
			tableuCase.add(new ArrayList<>());
			for (int x = 0; x < 8; x++) {
				tableuCase.get(y).add(new Case(x, y));
			}
		}
	}

	private void initialiserPion(Couleur couleur) {
		int y = couleur == Couleur.BLANC ? 1 : 6;

		for (int x = 0; x < 8; x++) {
			ajouterPiece(x, y, new Pion(couleur));
		}
	}

	private void initialiserTour(Couleur couleur) {
		int y = couleur == Couleur.BLANC ? 0 : 7;

		ajouterPiece(3, 3, new Tour(couleur));
		ajouterPiece(7, y, new Tour(couleur));
	}

	private void initialiserCavalier(Couleur couleur) {
		int y = couleur == Couleur.BLANC ? 0 : 7;

		ajouterPiece(1, y, new Cavalier(couleur));
		ajouterPiece(6, y, new Cavalier(couleur));
	}

	private void initialiserFou(Couleur couleur) {
		int y = couleur == Couleur.BLANC ? 0 : 7;

		ajouterPiece(2, y, new Fou(couleur));
		ajouterPiece(5, y, new Fou(couleur));
	}

	private void initialiserDamme(Couleur couleur) {
		int y = couleur == Couleur.BLANC ? 0 : 7;

		ajouterPiece(4, y, new Damme(couleur));
	}

	private void initialiserRoi(Couleur couleur) {
		int y = couleur == Couleur.BLANC ? 0 : 7;

		ajouterPiece(1, 1, new Roi(couleur));
	}

	private void ajouterPiece(int x, int y, Piece piece) {
		tableuCase.get(y).get(x).assignerPiece(piece);
	}

	public Case getCase(int x, int y) {
		if (x < 0 || x > 7 || y < 0 || y > 7)
			return null;
		return tableuCase.get(y).get(x);
	}

	public Joueur getJoueurBlanc() {
		return joueurBlanc;
	}

	public Joueur getJoueurNoir() {
		return joueurNoir;
	}
	
	public void move(Case c, Case destination) {
		destination.assignerPiece(c.popPiece());
	}


	public int CountCase(Case casePiece, Vecteur vecteur){

		int count=0;
		int x=casePiece.getPossitionX();
		int y=casePiece.getPossitionY();
		int vx= vecteur.getX();
		int vy= vecteur.getY();

		while (getCase(x+vx, y+vy)!=null && getCase(x+vx, y+vy).isVide()==true){
			count++;
			vy+= vecteur.getY();
			vx+= vecteur.getX();
		}


		int caserestY=y+ (vecteur.getY()*count) + vecteur.getY() ;

		int carerestX=x+(vecteur.getX()*count)+ vecteur.getX();
		//getCase(x, caserestY).getPiece().getCouleur()) == getCase(x+vx, y+vy).getPiece().getCouleur();

		if (getCase(carerestX, caserestY)!=null && getCase(carerestX, caserestY).getPiece().getCouleur() != casePiece.getPiece().getCouleur()){
			count++;
		}

		//System.out.println(getCase(x, caserestY).getPiece().getCouleur());



		return count;
	}
	
	

}
