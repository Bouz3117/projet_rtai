package joueur;

import piece.Couleur;

public class JoueurNoir extends Joueur {

	public JoueurNoir() {
		super(Couleur.NOIR);
	}

}
