package joueur;

import piece.Couleur;

public class JoueurBlanc extends Joueur {

	public JoueurBlanc() {
		super(Couleur.BLANC);
	}

}
