package piece.pieceSpeciale;

import echiquier.Case;
import echiquier.Echiquier;
import piece.*;


public class Tour extends Piece {

	private DeplacementPosible deplacements;

	public Tour(Couleur couleur) {
		super(couleur, NomPiece.TOUR);
	}

	@Override
	public DeplacementPosible getDeplacement(Echiquier echiquier, int x, int y) {

				Vecteur v;
				int n;
				deplacements = new DeplacementPosible();

				v = new Vecteur(0,-1);
				n=echiquier.CountCase(echiquier.getCase(x, y), v);
				for (int i=1; i<=n; i++)
					deplacements.addDeplacement(0, -i);

				v = new Vecteur(0,1);
				n=echiquier.CountCase(echiquier.getCase(x, y), v);
				for (int i=1; i<=n; i++)
					deplacements.addDeplacement(0, i);

				v = new Vecteur(-1,1);
				n=echiquier.CountCase(echiquier.getCase(x, y), v);
				for (int i=1; i<=n; i++)
					deplacements.addDeplacement(-i, -i);

		/*if (echiquier.getCase(x, y + vecteurY).caseVide()) {
			deplacements.addDeplacement(-vecteurY, 0); // droite
			deplacements.addDeplacement(vecteurY, 0);  // gauche
		}*/

		return deplacements;

	}

}
