package piece;

public enum NomPiece {
	PION, TOUR, CAVALIER, FOU, DAMME, ROI
}
