package piece;

public enum Couleur {
	BLANC, NOIR
}
