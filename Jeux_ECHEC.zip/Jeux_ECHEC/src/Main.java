// Press Shift twice to open the Search Everywhere dialog and type `show whitespaces`,
// then press Enter. You can now see whitespace characters in your code.
public class Main {
    public static void main(String[] args) {
             new Jeux_Echec();
        }
}


/* CLIQUE GAUCHE POUR SELECTIONNER PIECE, CLIQUE DROIT POUR SELECTIONNER CASE DE DEPLACEMENT */