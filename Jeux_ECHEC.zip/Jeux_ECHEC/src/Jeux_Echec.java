import javax.swing.*;
import java.awt.*;
import java.awt.event.MouseEvent;
import java.awt.event.MouseListener;

public class Jeux_Echec extends JFrame {
    private JPanel Echiquier, selected;   // ajout des case dans la fenetre

    private String color="", piece="";
    private int index = -1, destination=-1;
    public Jeux_Echec() {

        this.setTitle("Jeux Echec Projet RTAI"); // titre de ma fenetre
        this.setSize(800, 800); // taille de ma fenetre

        this.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE); // fermeture de la fenetre lorsque on clique sur X

        Plateau_Echiquier();

        AjoutTousPieces(); // ajouter les pieces dans le plateau echiquier

        addMouseListener(); // pour crée un évenement lorsque un utilisateur utilise la souris

        add(Echiquier);
        this.setLocationRelativeTo(null);
        this.setVisible(true);

    }

        private void addMouseListener() {
        Echiquier.addMouseListener(new MouseListener() {
            @Override
            public void mouseClicked(MouseEvent e) {
                try {
                    if (e.getButton() == 1) {// si le user clique sur le bouton de gauche de la souris
                        index = getComponentIndex(e.getPoint());  //Pour savoir quelle case l'utilisateur à cliquer dessus et puis la stocker dans index
                        selected = (JPanel) Echiquier.getComponent(index);
                        if (selected.getComponentCount() > 0) {
                            getInfoFromIndex();
                            if (piece.equals("Pion")) {
                                DeplacementsPions();
                            } else if (piece.equals("Tour")) {
                                DeplacementsTours();

                            }
                        }
                    } else if (e.getButton() == 3) {

                        destination = getComponentIndex(e.getPoint());  // si le user clique sur la piece il peut la déplacer en cliquant sur le bouton de gauche de la souris et le bouton droit pour choisir la destination de la piece
                        try {
                            if (isSelected(destination)) {
                                if (isEmpty(destination)) { // vérifier si la case est vide pour déplacer la piece
                                    JPanel panel = (JPanel) Echiquier.getComponent(index);       // si on peut donc on remplace l'image de la piece sélectionnée dans la nouvelle case

                                    JLabel label = (JLabel) panel.getComponent(0);

                                    panel.removeAll();
                                    panel.revalidate();
                                    panel.repaint();

                                    panel = (JPanel) Echiquier.getComponent(destination);
                                    panel.removeAll();
                                    panel.add(label, BorderLayout.CENTER);
                                    panel.revalidate();
                                    panel.repaint();
                                }
                            }
                        } catch (Exception ex) {}
                    }
                } catch (Exception ex) {}
            }

            @Override
            public void mousePressed(MouseEvent e) {

            }

            @Override
            public void mouseReleased(MouseEvent e) {

            }

            @Override
            public void mouseEntered(MouseEvent e) {

            }

            @Override
            public void mouseExited(MouseEvent e) {

            }
        });
    }
        private int getComponentIndex(Point p){
        for (int i=0; i<Echiquier.getComponentCount(); i++){
            if(Echiquier.getComponent(i)==Echiquier.getComponentAt(p))
                return i;
            }

            return -1;
        }

        private void  getInfoFromIndex(){
        if(selected.getComponentCount() > 0){
            try {
                JLabel label = (JLabel) selected.getComponent(0);
                if (label.getIcon().toString().contains("Noires")) {
                    color = "Noires";
                }else{
                    color = "Blanches";
                }
                if (label.getIcon().toString().contains("Fou")) {
                    piece = "Fou";
                } else if (label.getIcon().toString().contains("Roi")) {
                    piece = "Roi";
                }else if (label.getIcon().toString().contains("Cavalier")) {
                    piece = "Cavalier";
                }else if (label.getIcon().toString().contains("Dame")) {
                    piece = "Dame";
                }else if (label.getIcon().toString().contains("Tour")) {
                    piece = "Tour";
                }else if (label.getIcon().toString().contains("Pion")) {
                    piece = "Pion";
                }

            }catch (Exception e){}
        }
        }

        private void DeplacementsPions(){
            try {
                int direction = -1, indice = 48;
                if(color.equals("Noires")){
                    direction =1;
                    indice =8;
                }
                if (isEmpty(index + (direction *8))){
                    setBorder(index + (direction *8));
                    if (index>= indice && index <= indice +7 && isEmpty(index + (direction *8) + (direction *8) )){
                        setBorder(index + (direction *8) + (direction *8) );
                    }
                }

            } catch (Exception e) {}
        }

        private void DeplacementsTours() {
            try {
                int count = 8;
                for (int i = 1; i <= 8; i++) {
                    if (isEmpty(index + count)) {  // bas vertical
                        setBorder(index + count);
                    }
                    count += 8;
                }
                count = 8;
                for (int i = 1; i <= 8; i++) {
                    if (isEmpty(index - count)) {  // haut vertical
                        setBorder(index - count);
                    }

                    count += 8;
                }
                count = 1;
                for (int i = 1; i <= 8; i++) {   // droite horizontal
                    if (index % 8 == 7)
                        break;

                    if (isEmpty(index + count)) {
                        setBorder(index + count);
                    }

                    if ((index + count) % 8 == 7)
                        break;

                    count += 1;
                }
                count = 1;
                for (int i = 1; i <= 8; i++) {   // gauche horizontal
                    if (index % 8 == 0)
                        break;

                    if (isEmpty(index - count)) {
                        setBorder(index - count);
                    }

                    if ((index - count) % 8 == 0) {
                        break;
                    }
                    count += 1;
                }
            }catch (Exception e) {

            }
        }


        private boolean isEmpty(int index) {
        try {
            JPanel panel = (JPanel) Echiquier.getComponent(index);
            if (panel.getComponentCount() == 0)
                return true;
        } catch (Exception ex) {}
        return false;
    }

        private boolean isSelected(int index){
            JPanel panel = (JPanel)  Echiquier.getComponent(index);
            return panel.getBorder() != null;
        }

        private void setBorder(int index){
            JPanel panel = (JPanel) Echiquier.getComponent(index);
            panel.setBorder(BorderFactory.createLineBorder(new Color(150,0,255),3));
        }

        private void Plateau_Echiquier(){
            boolean black =true;
            Echiquier = new JPanel(new GridLayout(8,8,2,2)); // configurer l'interface de l'echiquier cela crée une grille 8x8 de composants avec des marges de 2 pixels entre chaque composant
            for (int i = 0; i < 64; i++) {
                JPanel square = new JPanel(new BorderLayout()); // chaque case à un panel
                Echiquier.add(square); // mettre les cases dans mon Echiquier

                if (black) {
                    square.setBackground(Color.GRAY);
                } else {
                    square.setBackground(Color.WHITE);
                }

                // Changer la couleur pour chaque colonne sauf la dernière
                if (i % 8 != 7) {
                    black = !black;
                }
            }
        }

        private void AjoutTousPieces(){
             int index =8;
             String path = "/Images/Noires/Pion.png";
            for (int i=1; i<= 16; i++)  // boucle pour initialiser les pions des deux couleurs dans l'echiquier
            {
                AjoutPiece(index, path);
                if(i==8){
                    index=47;
                    path = "/Images/Blanches/Pion.png";
                }
                index ++;
            }

            /*
             Ajout Pièces Blanches dans l'interface d'echiquier
            */
            // AjoutPiece(24,"/Images/Noires/Tour.png"); // pour tester le déplacement d'une tour

            AjoutPiece(0,"/Images/Noires/Tour.png");
            AjoutPiece(1,"/Images/Noires/Cavalier.png");
            AjoutPiece(2,"/Images/Noires/Fou.png");
            AjoutPiece(3,"/Images/Noires/Roi.png");
            AjoutPiece(4,"/Images/Noires/Dame.png");
            AjoutPiece(5,"/Images/Noires/Fou.png");
            AjoutPiece(6,"/Images/Noires/Cavalier.png");
            AjoutPiece(7,"/Images/Noires/Tour.png");

            /*
             Ajout Pièces Noires dans l'interface d'echiquier
            */

            AjoutPiece(56,"/Images/Blanches/Tour.png");
            AjoutPiece(57,"/Images/Blanches/Cavalier.png");
            AjoutPiece(58,"/Images/Blanches/Fou.png");
            AjoutPiece(59,"/Images/Blanches/Roi.png");
            AjoutPiece(60,"/Images/Blanches/Dame.png");
            AjoutPiece(61,"/Images/Blanches/Fou.png");
            AjoutPiece(62,"/Images/Blanches/Cavalier.png");
            AjoutPiece(63,"/Images/Blanches/Tour.png");

        }
        private void AjoutPiece(int index, String path) {
             JPanel pan = (JPanel) Echiquier.getComponent(index);
            try {
            JLabel img = new JLabel(new ImageIcon(getClass().getResource(path)));
            pan.add(img, BorderLayout.CENTER);
            } catch (Exception ex) {
            ex.printStackTrace();
             }
        }
}



